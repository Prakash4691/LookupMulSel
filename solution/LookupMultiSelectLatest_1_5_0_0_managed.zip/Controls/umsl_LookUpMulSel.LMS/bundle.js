/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./LMS/LookupMultiSel.tsx":
/*!********************************!*\
  !*** ./LMS/LookupMultiSel.tsx ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   LookupMultiSel: () => (/* binding */ LookupMultiSel)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _fluentui_react_lib_Dropdown__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @fluentui/react/lib/MessageBar */ \"@fluentui/react/lib/Dropdown\");\n/* harmony import */ var _fluentui_react_lib_Dropdown__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_fluentui_react_lib_Dropdown__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _WebApiOperations__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./WebApiOperations */ \"./LMS/WebApiOperations.ts\");\n\n\n\n\n\n\n\n\n\nvar dropdownStyles = {\n  dropdown: {\n    width: \"100%\",\n    selectors: {\n      // Remove strong outer focus ring; keep outline off to rely on internal element focus visuals\n      \"&:focus\": {\n        borderColor: \"#e1dfdd\",\n        boxShadow: \"none\",\n        outline: \"none\"\n      },\n      \"&:hover\": {\n        borderColor: \"#d2d0ce\"\n      }\n    }\n  },\n  root: {\n    width: \"100%\"\n  },\n  callout: {\n    maxHeight: \"200px\",\n    borderRadius: \"2px\",\n    boxShadow: \"0 1.6px 3.6px 0 rgba(0, 0, 0, 0.132), 0 0.3px 0.9px 0 rgba(0, 0, 0, 0.108)\",\n    border: \"1px solid #e1dfdd\"\n  },\n  dropdownItemsWrapper: {\n    maxHeight: \"inherit\"\n  },\n  title: {\n    borderRadius: \"2px\",\n    minHeight: \"32px\",\n    padding: \"8px 40px 8px 12px\",\n    fontSize: \"14px\",\n    lineHeight: \"20px\",\n    backgroundColor: \"#ffffff\",\n    selectors: {\n      \"&:hover\": {\n        borderColor: \"#d2d0ce\"\n      }\n    }\n  },\n  caretDownWrapper: {\n    color: \"#605e5c\",\n    fontSize: \"16px\",\n    selectors: {\n      \"&:hover\": {\n        color: \"#0078d4\"\n      }\n    }\n  }\n};\nvar searchBoxStyles = {\n  clearButton: {\n    display: \"none\"\n  },\n  root: {\n    margin: \"8px 12px\",\n    borderRadius: \"2px\"\n  },\n  field: {\n    fontSize: \"14px\",\n    padding: \"8px 12px\",\n    border: \"1px solid #d2d0ce\",\n    borderRadius: \"2px\"\n  }\n};\nvar stackTokens = {\n  childrenGap: 4,\n  padding: 0\n};\nvar buttonStyles = {\n  icon: {\n    fontSize: \"12px\",\n    color: \"#666666\"\n  },\n  root: {\n    height: \"24px\",\n    width: \"24px\",\n    minWidth: \"24px\"\n  }\n};\nvar LookupMultiSel = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.memo(props => {\n  var {\n    onChange,\n    initialValues,\n    context,\n    relatedEntityType,\n    relatedPrimaryColumns,\n    primaryEntityType,\n    relationshipName,\n    primaryEntityId,\n    disabled\n  } = props;\n  var [selectedValues, setSelectedValues] = react__WEBPACK_IMPORTED_MODULE_0__.useState([]);\n  var [userOptions, setUserOptions] = react__WEBPACK_IMPORTED_MODULE_0__.useState([]);\n  var [isLoading, setIsLoading] = react__WEBPACK_IMPORTED_MODULE_0__.useState(true);\n  var [error, setError] = react__WEBPACK_IMPORTED_MODULE_0__.useState(\"\");\n  var onChangeTriggered = react__WEBPACK_IMPORTED_MODULE_0__.useRef(false);\n  var [searchText, setSearchText] = react__WEBPACK_IMPORTED_MODULE_0__.useState(\"\");\n  var [debouncedSearchText, setDebouncedSearchText] = react__WEBPACK_IMPORTED_MODULE_0__.useState(\"\");\n  var searchTimeoutRef = react__WEBPACK_IMPORTED_MODULE_0__.useRef();\n  // Derived dropdown state - smart filtering that preserves selected options\n  var selectedOptions = userOptions.filter(opt => selectedValues.includes(opt.key));\n  var unselectedOptions = userOptions.filter(opt => !selectedValues.includes(opt.key));\n  var filteredUnselectedOptions = unselectedOptions.filter(opt => opt.text.toLocaleLowerCase().indexOf(debouncedSearchText.toLocaleLowerCase()) > -1);\n  var filteredOptions = [...selectedOptions, ...filteredUnselectedOptions];\n  var hasSearchText = debouncedSearchText.trim().length > 0;\n  var hasResults = filteredUnselectedOptions.length > 0 || selectedOptions.length > 0;\n  var noResults = hasSearchText && filteredUnselectedOptions.length === 0 && selectedOptions.length === 0;\n  // Adjust dropdown styles to remove scrolling when \"no results\" message shown\n  var adjustedDropdownStyles = react__WEBPACK_IMPORTED_MODULE_0__.useMemo(() => {\n    if (noResults) {\n      return Object.assign(Object.assign({}, dropdownStyles), {\n        callout: Object.assign(Object.assign({}, dropdownStyles.callout || {}), {\n          maxHeight: \"none\"\n        }),\n        dropdownItemsWrapper: {\n          maxHeight: \"none\"\n        }\n      });\n    }\n    return dropdownStyles;\n  }, [noResults]);\n  /**\n   * Debounce search text to improve performance\n   */\n  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(() => {\n    if (searchTimeoutRef.current) {\n      clearTimeout(searchTimeoutRef.current);\n    }\n    searchTimeoutRef.current = setTimeout(() => {\n      setDebouncedSearchText(searchText);\n    }, 300);\n    return () => {\n      if (searchTimeoutRef.current) {\n        clearTimeout(searchTimeoutRef.current);\n      }\n    };\n  }, [searchText]);\n  /**\n   * Sync selected values with incoming initialValues (handles re-publish / control reload)\n   */\n  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(() => {\n    var areEqual = function areEqual() {\n      var a = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];\n      var b = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : [];\n      if (a.length !== b.length) return false;\n      var as = [...a].sort();\n      var bs = [...b].sort();\n      for (var i = 0; i < as.length; i++) if (as[i] !== bs[i]) return false;\n      return true;\n    };\n    if (!areEqual(selectedValues, initialValues)) {\n      setSelectedValues(initialValues !== null && initialValues !== void 0 ? initialValues : []);\n    }\n  }, [initialValues]);\n  /**\n   * Retrieves entity records using webapi and maintain using state\n   */\n  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(() => {\n    var userOptionsList = [];\n    setIsLoading(true);\n    setError(\"\");\n    context.webAPI.retrieveMultipleRecords(relatedEntityType).then(response => {\n      response.entities.forEach(element => {\n        userOptionsList.push({\n          key: element[relatedPrimaryColumns[0]],\n          text: element[relatedPrimaryColumns[1]],\n          data: {\n            value: element[relatedPrimaryColumns[0]]\n          }\n        });\n      });\n      setUserOptions(userOptionsList);\n      setIsLoading(false);\n    }).catch(error => {\n      console.error(\"Error retrieving records:\", error);\n      setError(\"Failed to load records. Please try again.\");\n      setIsLoading(false);\n      context.navigation.openAlertDialog(error);\n    });\n  }, []);\n  /**\n   * Trigger onchange to update the property\n   */\n  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(() => {\n    if (onChangeTriggered.current) onChange(selectedValues);\n  }, [selectedValues]);\n  /**\n   * Triggers on change of dropdown\n   * @param ev Event of the dropdown\n   * @param option Selected option from dropdown\n   * @param eventId Event to identify is it for dropdown or cancel icon\n   */\n  var onChangeDropDownOrOnIconClick = (ev, option, eventId) => {\n    if (eventId === 1) {\n      var iconEvent = ev;\n      iconEvent.stopPropagation();\n    }\n    if (option) {\n      onChangeTriggered.current = true;\n      setSelectedValues(option.selected ? [...selectedValues, option.key] : selectedValues.filter(key => key != option.key));\n    }\n    if (option === null || option === void 0 ? void 0 : option.selected) (0,_WebApiOperations__WEBPACK_IMPORTED_MODULE_2__.Associate)(context, option.key, primaryEntityType, relatedEntityType, relationshipName, primaryEntityId);else if (!(option === null || option === void 0 ? void 0 : option.selected)) (0,_WebApiOperations__WEBPACK_IMPORTED_MODULE_2__.DisAssociate)(context, option === null || option === void 0 ? void 0 : option.key, primaryEntityType, relationshipName, primaryEntityId);\n  };\n  /**\n   *Render icon of the dropdown to search\n   * @returns Icon\n   */\n  var onRenderCaretDown = () => {\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_lib_Dropdown__WEBPACK_IMPORTED_MODULE_1__.Icon, {\n      iconName: \"Search\"\n    });\n  };\n  /**\n   * Render drop down item event\n   * @param option Drop down item\n   * @returns\n   */\n  var onRenderOption = option => {\n    if ((option === null || option === void 0 ? void 0 : option.itemType) === _fluentui_react_lib_Dropdown__WEBPACK_IMPORTED_MODULE_1__.DropdownMenuItemType.Header) {\n      if (option.key === \"FilterHeader\") {\n        return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_lib_Dropdown__WEBPACK_IMPORTED_MODULE_1__.SearchBox, {\n          onChange: (ev, newValue) => setSearchText(newValue || \"\"),\n          underlined: false,\n          placeholder: \"Search options...\",\n          autoFocus: true,\n          styles: searchBoxStyles,\n          iconProps: {\n            iconName: \"Search\"\n          },\n          clearButtonProps: {\n            ariaLabel: \"Clear search\"\n          },\n          ariaLabel: \"Search dropdown options\"\n        });\n      } else if (option.key === \"no-results\") {\n        return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n          className: \"no-results-message\"\n        }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_lib_Dropdown__WEBPACK_IMPORTED_MODULE_1__.Icon, {\n          iconName: \"Search\",\n          className: \"no-results-icon\"\n        }), option.text);\n      }\n    }\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n      className: \"dropdown-option-item\"\n    }, option === null || option === void 0 ? void 0 : option.text);\n  };\n  /**\n   * Render custom title with selected items as chips/tags\n   * @param options Selected option from dropdown\n   * @returns\n   */\n  var onRenderTitle = options => {\n    var selectedList = options;\n    if (selectedList.length === 0) {\n      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"span\", {\n        className: \"placeholder-text\"\n      }, \"Look for records\");\n    }\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_lib_Dropdown__WEBPACK_IMPORTED_MODULE_1__.Stack, {\n      horizontal: true,\n      wrap: true,\n      tokens: stackTokens,\n      className: \"selected-items-container\"\n    }, selectedList.map((element, index) => (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n      key: element.key,\n      className: \"selected-item-chip\"\n    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"span\", {\n      title: element.text,\n      className: \"selected-item-text\"\n    }, element.text), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_lib_Dropdown__WEBPACK_IMPORTED_MODULE_1__.IconButton, {\n      iconProps: {\n        iconName: \"Cancel\"\n      },\n      title: \"Remove \".concat(element.text),\n      onClick: ev => onChangeDropDownOrOnIconClick(ev, element, 1),\n      className: \"remove-chip-button\"\n    })))));\n  };\n  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, error && (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    className: \"error-container\"\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_lib_Dropdown__WEBPACK_IMPORTED_MODULE_1__.MessageBar, {\n    messageBarType: _fluentui_react_lib_Dropdown__WEBPACK_IMPORTED_MODULE_1__.MessageBarType.error,\n    isMultiline: false,\n    onDismiss: () => setError(\"\")\n  }, error))), isLoading ? (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    className: \"loading-container\"\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_lib_Dropdown__WEBPACK_IMPORTED_MODULE_1__.Spinner, {\n    size: _fluentui_react_lib_Dropdown__WEBPACK_IMPORTED_MODULE_1__.SpinnerSize.medium,\n    label: \"Loading records...\"\n  }))) : (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_lib_Dropdown__WEBPACK_IMPORTED_MODULE_1__.Dropdown, Object.assign({}, userOptions, {\n    options: (() => {\n      var options = [{\n        key: \"FilterHeader\",\n        text: \"-\",\n        itemType: _fluentui_react_lib_Dropdown__WEBPACK_IMPORTED_MODULE_1__.DropdownMenuItemType.Header\n      }, {\n        key: \"divider_filterHeader\",\n        text: \"-\",\n        itemType: _fluentui_react_lib_Dropdown__WEBPACK_IMPORTED_MODULE_1__.DropdownMenuItemType.Divider\n      }];\n      if (noResults) {\n        options.push({\n          key: \"no-results\",\n          text: \"No results found for \\\"\".concat(debouncedSearchText, \"\\\"\"),\n          itemType: _fluentui_react_lib_Dropdown__WEBPACK_IMPORTED_MODULE_1__.DropdownMenuItemType.Header\n        });\n      } else {\n        options.push(...filteredOptions);\n      }\n      return options;\n    })(),\n    styles: adjustedDropdownStyles,\n    multiSelect: true,\n    onChange: onChangeDropDownOrOnIconClick,\n    selectedKeys: selectedValues,\n    calloutProps: {\n      directionalHintFixed: true,\n      isBeakVisible: false\n    },\n    onRenderTitle: onRenderTitle,\n    id: \"MainDropDown\",\n    placeholder: \"Look for records\",\n    onRenderCaretDown: onRenderCaretDown,\n    onRenderOption: onRenderOption,\n    onDismiss: () => {\n      setSearchText(\"\");\n      setDebouncedSearchText(\"\");\n    },\n    disabled: disabled,\n    ariaLabel: \"Multi-select lookup field\",\n    \"data-testid\": \"lookup-multiselect-dropdown\"\n  }))));\n});\nLookupMultiSel.displayName = \"LookupMultiSel\";\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./LMS/LookupMultiSel.tsx?\n}");

/***/ }),

/***/ "./LMS/WebApiOperations.ts":
/*!*********************************!*\
  !*** ./LMS/WebApiOperations.ts ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   Associate: () => (/* binding */ Associate),\n/* harmony export */   DisAssociate: () => (/* binding */ DisAssociate)\n/* harmony export */ });\n/*global Xrm */\n/*eslint no-undef: \"error\"*/\n//@ts-ignore\nvar url = Xrm.Utility.getGlobalContext().getClientUrl();\n/**\n * Associate selected record\n * @param selectedKey\n * @param primaryEntityType\n * @param relatedEntityType\n * @param relationshipName\n * @param primaryEntityId\n */\nvar Associate = (context, selectedKey, primaryEntityType, relatedEntityType, relationshipName, primaryEntityId) => {\n  var error = \"Issue while associating the record. Kindly check the configuration.\";\n  var association = {\n    \"@odata.id\": url + \"/api/data/v9.1/\".concat(relatedEntityType, \"s(\").concat(selectedKey, \")\")\n  };\n  var req = new XMLHttpRequest();\n  req.open(\"POST\", url + \"/api/data/v9.1/\".concat(primaryEntityType, \"s(\").concat(primaryEntityId, \")/\").concat(relationshipName, \"/$ref\"), true);\n  req.setRequestHeader(\"Accept\", \"application/json\");\n  req.setRequestHeader(\"Content-Type\", \"application/json; charset=utf-8\");\n  req.setRequestHeader(\"OData-MaxVersion\", \"4.0\");\n  req.setRequestHeader(\"OData-Version\", \"4.0\");\n  req.onreadystatechange = function () {\n    if (this.readyState === 4) {\n      req.onreadystatechange = null;\n      if (this.status === 204 || this.status === 1223) {\n        console.log(\"Associated\");\n      } else {\n        context.navigation.openAlertDialog(error);\n      }\n    }\n  };\n  req.send(JSON.stringify(association));\n};\n/**\n * Disassociate cancelled/unselected record\n * @param removedKey\n * @param primaryEntityType\n * @param relationshipName\n * @param primaryEntityId\n */\nvar DisAssociate = (context, removedKey, primaryEntityType, relationshipName, primaryEntityId) => {\n  var error = \"Issue while disassociating the record. Kindly check the configuration.\";\n  var req = new XMLHttpRequest();\n  req.open(\"DELETE\", url + \"/api/data/v9.1/\".concat(primaryEntityType, \"s(\").concat(primaryEntityId, \")/\").concat(relationshipName, \"(\").concat(removedKey, \")/$ref\"), true);\n  req.setRequestHeader(\"Accept\", \"application/json\");\n  req.setRequestHeader(\"Content-Type\", \"application/json; charset=utf-8\");\n  req.setRequestHeader(\"OData-MaxVersion\", \"4.0\");\n  req.setRequestHeader(\"OData-Version\", \"4.0\");\n  req.onreadystatechange = function () {\n    if (this.readyState === 4) {\n      req.onreadystatechange = null;\n      if (this.status === 204 || this.status === 1223) {\n        console.log(\"Disassociated\");\n      } else {\n        context.navigation.openAlertDialog(error);\n      }\n    }\n  };\n  req.send();\n};\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./LMS/WebApiOperations.ts?\n}");

/***/ }),

/***/ "./LMS/index.ts":
/*!**********************!*\
  !*** ./LMS/index.ts ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   LMS: () => (/* binding */ LMS)\n/* harmony export */ });\n/* harmony import */ var _LookupMultiSel__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./LookupMultiSel */ \"./LMS/LookupMultiSel.tsx\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n\n\nclass LMS {\n  /**\n   * Empty constructor.\n   */\n  constructor() {\n    this.previousMultiSelectedValues = null;\n    this.onChange = selectedValue => {\n      this.selectedOptions = selectedValue;\n      this.notifyOutputChanged();\n    };\n  }\n  /**\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\n   * Data-set values are not initialized here, use updateView.\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\n   */\n  init(context, notifyOutputChanged, state) {\n    this.notifyOutputChanged = notifyOutputChanged;\n    // Initialize with empty array - values will be set in updateView when property becomes available\n    this.initialValues = [];\n  }\n  /**\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\n   * @returns ReactElement root react element for the control\n   */\n  updateView(context) {\n    // Handle initial values from bound property - update when property becomes available or changes\n    var currentMultiSelectedValues = context.parameters.multiSelectedValues.raw;\n    if (currentMultiSelectedValues !== this.previousMultiSelectedValues) {\n      this.previousMultiSelectedValues = currentMultiSelectedValues;\n      this.initialValues = currentMultiSelectedValues == null ? [] : currentMultiSelectedValues.split(\",\").map(value => value.trim()).filter(value => value.length > 0);\n    }\n    var props = {\n      onChange: this.onChange,\n      initialValues: this.initialValues,\n      context: context,\n      relatedEntityType: context.parameters.relatedEntityType.raw,\n      relatedPrimaryColumns: context.parameters.relatedPrimaryColumns.raw.split(\",\").map(value => value.trim()),\n      primaryEntityType: context.parameters.primaryEntityType.raw,\n      relationshipName: context.parameters.relationshipName.raw,\n      primaryEntityId: context.parameters.primaryEntityId.raw,\n      disabled: context.parameters.primaryEntityId.raw == null ? true : context.mode.isControlDisabled\n    };\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1__.createElement(_LookupMultiSel__WEBPACK_IMPORTED_MODULE_0__.LookupMultiSel, props);\n  }\n  /**\n   * It is called by the framework prior to a control receiving new data.\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\n   */\n  getOutputs() {\n    return {\n      multiSelectedValues: this.selectedOptions.toString()\n    };\n  }\n  /**\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\n   */\n  destroy() {\n    // Add code to cleanup control if necessary\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./LMS/index.ts?\n}");

/***/ }),

/***/ "@fluentui/react/lib/Dropdown":
/*!*************************************!*\
  !*** external "FluentUIReactv8290" ***!
  \*************************************/
/***/ ((module) => {

module.exports = FluentUIReactv8290;

/***/ }),

/***/ "react":
/*!***************************!*\
  !*** external "Reactv16" ***!
  \***************************/
/***/ ((module) => {

module.exports = Reactv16;

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./LMS/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('LookUpMulSel.LMS', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.LMS);
} else {
	var LookUpMulSel = LookUpMulSel || {};
	LookUpMulSel.LMS = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.LMS;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}