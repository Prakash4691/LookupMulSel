/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./LMS/LookupMultiSel.tsx":
/*!********************************!*\
  !*** ./LMS/LookupMultiSel.tsx ***!
  \********************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

eval("\n\nvar __assign = this && this.__assign || function () {\n  __assign = Object.assign || function (t) {\n    for (var s, i = 1, n = arguments.length; i < n; i++) {\n      s = arguments[i];\n      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];\n    }\n    return t;\n  };\n  return __assign.apply(this, arguments);\n};\nvar __spreadArray = this && this.__spreadArray || function (to, from, pack) {\n  if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {\n    if (ar || !(i in from)) {\n      if (!ar) ar = Array.prototype.slice.call(from, 0, i);\n      ar[i] = from[i];\n    }\n  }\n  return to.concat(ar || Array.prototype.slice.call(from));\n};\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.LookupMultiSel = void 0;\nvar React = __webpack_require__(/*! react */ \"react\");\nvar Dropdown_1 = __webpack_require__(/*! @fluentui/react/lib/Dropdown */ \"@fluentui/react/lib/Dropdown\");\nvar Button_1 = __webpack_require__(/*! @fluentui/react/lib/Button */ \"@fluentui/react/lib/Dropdown\");\nvar Icon_1 = __webpack_require__(/*! @fluentui/react/lib/Icon */ \"@fluentui/react/lib/Dropdown\");\nvar SearchBox_1 = __webpack_require__(/*! @fluentui/react/lib/SearchBox */ \"@fluentui/react/lib/Dropdown\");\n//import { Sticky } from \"@fluentui/react\";\nvar WebApiOperations_1 = __webpack_require__(/*! ./WebApiOperations */ \"./LMS/WebApiOperations.ts\");\nvar dropdownStyles = {\n  dropdown: {\n    width: 500,\n    height: \"auto\"\n  }\n};\nvar searchBoxStyles = {\n  clearButton: {\n    display: \"none\"\n  }\n};\n//const stackTokens: IStackTokens = { childrenGap: 10 };\nvar buttonStyles = {\n  icon: {\n    fontSize: \"11px\"\n  }\n};\nexports.LookupMultiSel = React.memo(function (props) {\n  var onChange = props.onChange,\n    initialValues = props.initialValues,\n    context = props.context,\n    relatedEntityType = props.relatedEntityType,\n    relatedPrimaryColumns = props.relatedPrimaryColumns,\n    primaryEntityType = props.primaryEntityType,\n    relationshipName = props.relationshipName,\n    primaryEntityId = props.primaryEntityId,\n    isEnabled = props.isEnabled;\n  var _a = React.useState([]),\n    selectedValues = _a[0],\n    setSelectedValues = _a[1];\n  var _b = React.useState([]),\n    userOptions = _b[0],\n    setUserOptions = _b[1];\n  var onChangeTriggered = React.useRef(false);\n  var _c = React.useState(\"\"),\n    searchText = _c[0],\n    setSearchText = _c[1];\n  /**\r\n   * Gets selected values from props and maintain using state\r\n   */\n  React.useEffect(function () {\n    setSelectedValues(initialValues);\n  }, []);\n  /**\r\n   * Retrieves entity records using webapi and maintain using state\r\n   */\n  React.useEffect(function () {\n    var userOptionsList = [];\n    context.webAPI.retrieveMultipleRecords(relatedEntityType).then(function (response) {\n      response.entities.forEach(function (element) {\n        userOptionsList.push({\n          key: element[relatedPrimaryColumns[0]],\n          text: element[relatedPrimaryColumns[1]],\n          data: {\n            value: element[relatedPrimaryColumns[0]]\n          }\n        });\n      });\n      setUserOptions(userOptionsList);\n    }).catch(function (error) {\n      context.navigation.openAlertDialog(error);\n    });\n    /* let userOptionsList = RetrieveMultiple(context, entityType, entityColumns);\r\n    setUserOptions(userOptionsList); */\n  }, []);\n  /**\r\n   * Trigger onchange to update the property\r\n   */\n  React.useEffect(function () {\n    var selectedValueOptions = [];\n    selectedValueOptions.push(selectedValues.toString());\n    if (onChangeTriggered.current) onChange(selectedValueOptions);\n  }, [selectedValues]);\n  /**\r\n   * Triggers on change of dropdown\r\n   * @param ev Event of the dropdown\r\n   * @param option Selected option from dropdown\r\n   * @param eventId Event to identify is it for dropdown or cancel icon\r\n   */\n  var onChangeDropDownOrOnIconClick = function onChangeDropDownOrOnIconClick(ev, option, eventId) {\n    if (eventId === 1) {\n      var iconEvent = ev;\n      iconEvent.stopPropagation();\n    }\n    if (option) {\n      onChangeTriggered.current = true;\n      setSelectedValues(option.selected ? __spreadArray(__spreadArray([], selectedValues, true), [option.key], false) : selectedValues.filter(function (key) {\n        return key != option.key;\n      }));\n    }\n    if (option === null || option === void 0 ? void 0 : option.selected) (0, WebApiOperations_1.Associate)(context, option.key, primaryEntityType, relatedEntityType, relationshipName, primaryEntityId);else if (!(option === null || option === void 0 ? void 0 : option.selected)) (0, WebApiOperations_1.DisAssociate)(context, option === null || option === void 0 ? void 0 : option.key, primaryEntityType, relationshipName, primaryEntityId);\n  };\n  /**\r\n   *Render icon of the dropdown to search\r\n   * @returns Icon\r\n   */\n  var onRenderCaretDown = function onRenderCaretDown() {\n    return React.createElement(Icon_1.Icon, {\n      iconName: \"Search\"\n    });\n  };\n  /**\r\n   * Render drop down item event\r\n   * @param option Drop down item\r\n   * @returns\r\n   */\n  var onRenderOption = function onRenderOption(option) {\n    return (option === null || option === void 0 ? void 0 : option.itemType) === Dropdown_1.DropdownMenuItemType.Header && option.key === \"FilterHeader\" ? React.createElement(SearchBox_1.SearchBox, {\n      onChange: function onChange(ev, newValue) {\n        return setSearchText(newValue);\n      },\n      underlined: true,\n      placeholder: \"Search options\",\n      autoFocus: true,\n      styles: searchBoxStyles\n    }) : React.createElement(React.Fragment, null, option === null || option === void 0 ? void 0 : option.text);\n  };\n  /**\r\n   * Render custom title\r\n   * @param options Selected option from dropdown\r\n   * @returns\r\n   */\n  var onRenderTitle = function onRenderTitle(options) {\n    var option = [];\n    var selectedList = options;\n    //let url: string = `main.aspx?pagetype=entityrecord&etn=${entityType}&id=`;\n    selectedList.forEach(function (element) {\n      option.push(React.createElement(\"span\", null, element.text, React.createElement(Button_1.IconButton, {\n        iconProps: {\n          iconName: \"Cancel\"\n        },\n        title: element.text,\n        onClick: function onClick(ev) {\n          return onChangeDropDownOrOnIconClick(ev, element, 1);\n        },\n        className: \"IconButtonClass\",\n        styles: buttonStyles\n      })));\n    });\n    return React.createElement(\"div\", null, option);\n  };\n  return React.createElement(React.Fragment, null, React.createElement(Dropdown_1.Dropdown, __assign({}, userOptions, {\n    options: __spreadArray([{\n      key: \"FilterHeader\",\n      text: \"-\",\n      itemType: Dropdown_1.DropdownMenuItemType.Header\n    }, {\n      key: \"divider_filterHeader\",\n      text: \"-\",\n      itemType: Dropdown_1.DropdownMenuItemType.Divider\n    }], userOptions.filter(function (opt) {\n      return opt.text.toLocaleLowerCase().indexOf(searchText.toLocaleLowerCase()) > -1;\n    }), true),\n    styles: dropdownStyles,\n    multiSelect: true,\n    onChange: onChangeDropDownOrOnIconClick,\n    selectedKeys: selectedValues,\n    calloutProps: {\n      directionalHintFixed: true\n    },\n    onRenderTitle: onRenderTitle,\n    //dropdownWidth=\"auto\"\n    id: \"MainDropDown\",\n    placeholder: \"Look for records\",\n    onRenderCaretDown: onRenderCaretDown,\n    onRenderOption: onRenderOption,\n    onDismiss: function onDismiss() {\n      return setSearchText(\"\");\n    },\n    disabled: isEnabled\n  })));\n});\nexports.LookupMultiSel.displayName = \"LookupMultiSel\";\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./LMS/LookupMultiSel.tsx?");

/***/ }),

/***/ "./LMS/WebApiOperations.ts":
/*!*********************************!*\
  !*** ./LMS/WebApiOperations.ts ***!
  \*********************************/
/***/ ((__unused_webpack_module, exports) => {

eval("\n\n/*global Xrm */\n/*eslint no-undef: \"error\"*/\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.DisAssociate = exports.Associate = void 0;\n//@ts-ignore\nvar url = Xrm.Utility.getGlobalContext().getClientUrl();\n/**\r\n * Associate selected record\r\n * @param selectedKey\r\n * @param primaryEntityType\r\n * @param relatedEntityType\r\n * @param relationshipName\r\n * @param primaryEntityId\r\n */\nvar Associate = function Associate(context, selectedKey, primaryEntityType, relatedEntityType, relationshipName, primaryEntityId) {\n  var error = \"Issue while associating the record. Kindly check the configuration.\";\n  var association = {\n    \"@odata.id\": url + \"/api/data/v9.1/\".concat(relatedEntityType, \"s(\").concat(selectedKey, \")\")\n  };\n  var req = new XMLHttpRequest();\n  req.open(\"POST\", url + \"/api/data/v9.1/\".concat(primaryEntityType, \"s(\").concat(primaryEntityId, \")/\").concat(relationshipName, \"/$ref\"), true);\n  req.setRequestHeader(\"Accept\", \"application/json\");\n  req.setRequestHeader(\"Content-Type\", \"application/json; charset=utf-8\");\n  req.setRequestHeader(\"OData-MaxVersion\", \"4.0\");\n  req.setRequestHeader(\"OData-Version\", \"4.0\");\n  req.onreadystatechange = function () {\n    if (this.readyState === 4) {\n      req.onreadystatechange = null;\n      if (this.status === 204 || this.status === 1223) {\n        console.log(\"Associated\");\n      } else {\n        context.navigation.openAlertDialog(error);\n      }\n    }\n  };\n  req.send(JSON.stringify(association));\n};\nexports.Associate = Associate;\n/**\r\n * Disassociate cancelled/unselected record\r\n * @param removedKey\r\n * @param primaryEntityType\r\n * @param relationshipName\r\n * @param primaryEntityId\r\n */\nvar DisAssociate = function DisAssociate(context, removedKey, primaryEntityType, relationshipName, primaryEntityId) {\n  var error = \"Issue while disassociating the record. Kindly check the configuration.\";\n  var req = new XMLHttpRequest();\n  req.open(\"DELETE\", url + \"/api/data/v9.1/\".concat(primaryEntityType, \"s(\").concat(primaryEntityId, \")/\").concat(relationshipName, \"(\").concat(removedKey, \")/$ref\"), true);\n  req.setRequestHeader(\"Accept\", \"application/json\");\n  req.setRequestHeader(\"Content-Type\", \"application/json; charset=utf-8\");\n  req.setRequestHeader(\"OData-MaxVersion\", \"4.0\");\n  req.setRequestHeader(\"OData-Version\", \"4.0\");\n  req.onreadystatechange = function () {\n    if (this.readyState === 4) {\n      req.onreadystatechange = null;\n      if (this.status === 204 || this.status === 1223) {\n        console.log(\"Disassociated\");\n      } else {\n        context.navigation.openAlertDialog(error);\n      }\n    }\n  };\n  req.send();\n};\nexports.DisAssociate = DisAssociate;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./LMS/WebApiOperations.ts?");

/***/ }),

/***/ "./LMS/index.ts":
/*!**********************!*\
  !*** ./LMS/index.ts ***!
  \**********************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

eval("\n\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.LMS = void 0;\nvar LookupMultiSel_1 = __webpack_require__(/*! ./LookupMultiSel */ \"./LMS/LookupMultiSel.tsx\");\nvar React = __webpack_require__(/*! react */ \"react\");\nvar LMS = /** @class */function () {\n  /**\r\n   * Empty constructor.\r\n   */\n  function LMS() {\n    var _this = this;\n    this.onChange = function (selectedValue) {\n      _this.selectedOptions = selectedValue;\n      _this.notifyOutputChanged();\n    };\n  }\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   */\n  LMS.prototype.init = function (context, notifyOutputChanged, state) {\n    this.notifyOutputChanged = notifyOutputChanged;\n    var initialSelectedValues = context.parameters.multiSelectedValues.raw;\n    this.initialValues = initialSelectedValues == null ? [] : initialSelectedValues.split(\",\");\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   * @returns ReactElement root react element for the control\r\n   */\n  LMS.prototype.updateView = function (context) {\n    var props = {\n      onChange: this.onChange,\n      initialValues: this.initialValues,\n      context: context,\n      relatedEntityType: context.parameters.relatedEntityType.raw,\n      relatedPrimaryColumns: context.parameters.relatedPrimaryColumns.raw.split(\",\").map(function (value) {\n        return value.trim();\n      }),\n      primaryEntityType: context.parameters.primaryEntityType.raw,\n      relationshipName: context.parameters.relationshipName.raw,\n      primaryEntityId: context.parameters.primaryEntityId.raw,\n      isEnabled: context.mode.isControlDisabled\n    };\n    return React.createElement(LookupMultiSel_1.LookupMultiSel, props);\n  };\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n  LMS.prototype.getOutputs = function () {\n    return {\n      multiSelectedValues: this.selectedOptions.toString()\n    };\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n  LMS.prototype.destroy = function () {\n    // Add code to cleanup control if necessary\n  };\n  return LMS;\n}();\nexports.LMS = LMS;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./LMS/index.ts?");

/***/ }),

/***/ "@fluentui/react/lib/Dropdown":
/*!*************************************!*\
  !*** external "FluentUIReactv8290" ***!
  \*************************************/
/***/ ((module) => {

module.exports = FluentUIReactv8290;

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "React" ***!
  \************************/
/***/ ((module) => {

module.exports = React;

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./LMS/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('LookUpMulSel.LMS', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.LMS);
} else {
	var LookUpMulSel = LookUpMulSel || {};
	LookUpMulSel.LMS = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.LMS;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}