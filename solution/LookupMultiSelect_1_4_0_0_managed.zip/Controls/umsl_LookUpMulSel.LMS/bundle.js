/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./LMS/LookupMultiSel.tsx":
/*!********************************!*\
  !*** ./LMS/LookupMultiSel.tsx ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   LookupMultiSel: () => (/* binding */ LookupMultiSel)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _fluentui_react_lib_Dropdown__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @fluentui/react/lib/SearchBox */ \"@fluentui/react/lib/Dropdown\");\n/* harmony import */ var _fluentui_react_lib_Dropdown__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_fluentui_react_lib_Dropdown__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _WebApiOperations__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./WebApiOperations */ \"./LMS/WebApiOperations.ts\");\n\n\n\n\n\n//import { Sticky } from \"@fluentui/react\";\n\nvar dropdownStyles = {\n  dropdown: {\n    width: \"100%\",\n    selectors: {\n      \"&:focus\": {\n        borderColor: \"#0078d4\",\n        boxShadow: \"0 0 5px rgba(0, 120, 212, 0.5)\"\n      }\n    }\n  },\n  root: {\n    width: \"100%\"\n  },\n  callout: {\n    maxHeight: \"50vh\",\n    overflowY: \"auto\"\n  },\n  dropdownItemsWrapper: {\n    maxHeight: \"inherit\"\n  },\n  title: {\n    borderColor: \"#666666\",\n    selectors: {\n      \"&:hover\": {\n        borderColor: \"#333333\"\n      }\n    }\n  }\n};\nvar searchBoxStyles = {\n  clearButton: {\n    display: \"none\"\n  }\n};\n//const stackTokens: IStackTokens = { childrenGap: 10 };\nvar buttonStyles = {\n  icon: {\n    fontSize: \"11px\"\n  }\n};\nvar LookupMultiSel = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.memo(props => {\n  var {\n    onChange,\n    initialValues,\n    context,\n    relatedEntityType,\n    relatedPrimaryColumns,\n    primaryEntityType,\n    relationshipName,\n    primaryEntityId,\n    disabled\n  } = props;\n  var [selectedValues, setSelectedValues] = react__WEBPACK_IMPORTED_MODULE_0__.useState([]);\n  var [userOptions, setUserOptions] = react__WEBPACK_IMPORTED_MODULE_0__.useState([]);\n  var onChangeTriggered = react__WEBPACK_IMPORTED_MODULE_0__.useRef(false);\n  var [searchText, setSearchText] = react__WEBPACK_IMPORTED_MODULE_0__.useState(\"\");\n  /**\r\n   * Gets selected values from props and maintain using state\r\n   */\n  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(() => {\n    setSelectedValues(initialValues);\n  }, []);\n  /**\r\n   * Retrieves entity records using webapi and maintain using state\r\n   */\n  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(() => {\n    var userOptionsList = [];\n    context.webAPI.retrieveMultipleRecords(relatedEntityType).then(response => {\n      response.entities.forEach(element => {\n        userOptionsList.push({\n          key: element[relatedPrimaryColumns[0]],\n          text: element[relatedPrimaryColumns[1]],\n          data: {\n            value: element[relatedPrimaryColumns[0]]\n          }\n        });\n      });\n      setUserOptions(userOptionsList);\n    }).catch(error => {\n      context.navigation.openAlertDialog(error);\n    });\n    /* let userOptionsList = RetrieveMultiple(context, entityType, entityColumns);\r\n    setUserOptions(userOptionsList); */\n  }, []);\n  /**\r\n   * Trigger onchange to update the property\r\n   */\n  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(() => {\n    if (onChangeTriggered.current) onChange(selectedValues);\n  }, [selectedValues]);\n  /**\r\n   * Triggers on change of dropdown\r\n   * @param ev Event of the dropdown\r\n   * @param option Selected option from dropdown\r\n   * @param eventId Event to identify is it for dropdown or cancel icon\r\n   */\n  var onChangeDropDownOrOnIconClick = (ev, option, eventId) => {\n    if (eventId === 1) {\n      var iconEvent = ev;\n      iconEvent.stopPropagation();\n    }\n    if (option) {\n      onChangeTriggered.current = true;\n      setSelectedValues(option.selected ? [...selectedValues, option.key] : selectedValues.filter(key => key != option.key));\n    }\n    if (option === null || option === void 0 ? void 0 : option.selected) (0,_WebApiOperations__WEBPACK_IMPORTED_MODULE_2__.Associate)(context, option.key, primaryEntityType, relatedEntityType, relationshipName, primaryEntityId);else if (!(option === null || option === void 0 ? void 0 : option.selected)) (0,_WebApiOperations__WEBPACK_IMPORTED_MODULE_2__.DisAssociate)(context, option === null || option === void 0 ? void 0 : option.key, primaryEntityType, relationshipName, primaryEntityId);\n  };\n  /**\r\n   *Render icon of the dropdown to search\r\n   * @returns Icon\r\n   */\n  var onRenderCaretDown = () => {\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_lib_Dropdown__WEBPACK_IMPORTED_MODULE_1__.Icon, {\n      iconName: \"Search\"\n    });\n  };\n  /**\r\n   * Render drop down item event\r\n   * @param option Drop down item\r\n   * @returns\r\n   */\n  var onRenderOption = option => {\n    return (option === null || option === void 0 ? void 0 : option.itemType) === _fluentui_react_lib_Dropdown__WEBPACK_IMPORTED_MODULE_1__.DropdownMenuItemType.Header && option.key === \"FilterHeader\" ? (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_lib_Dropdown__WEBPACK_IMPORTED_MODULE_1__.SearchBox, {\n      onChange: (ev, newValue) => setSearchText(newValue),\n      underlined: true,\n      placeholder: \"Search options\",\n      autoFocus: true,\n      styles: searchBoxStyles\n    })) : (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, option === null || option === void 0 ? void 0 : option.text));\n  };\n  /**\r\n   * Render custom title\r\n   * @param options Selected option from dropdown\r\n   * @returns\r\n   */\n  var onRenderTitle = options => {\n    var option = [];\n    var selectedList = options;\n    //let url: string = `main.aspx?pagetype=entityrecord&etn=${entityType}&id=`;\n    selectedList.forEach(element => {\n      option.push(/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"span\", null, element.text, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_lib_Dropdown__WEBPACK_IMPORTED_MODULE_1__.IconButton, {\n        iconProps: {\n          iconName: \"Cancel\"\n        },\n        title: element.text,\n        onClick: ev => onChangeDropDownOrOnIconClick(ev, element, 1),\n        className: \"IconButtonClass\",\n        styles: buttonStyles\n      })));\n    });\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", null, option);\n  };\n  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_lib_Dropdown__WEBPACK_IMPORTED_MODULE_1__.Dropdown, Object.assign({}, userOptions, {\n    options: [{\n      key: \"FilterHeader\",\n      text: \"-\",\n      itemType: _fluentui_react_lib_Dropdown__WEBPACK_IMPORTED_MODULE_1__.DropdownMenuItemType.Header\n    }, {\n      key: \"divider_filterHeader\",\n      text: \"-\",\n      itemType: _fluentui_react_lib_Dropdown__WEBPACK_IMPORTED_MODULE_1__.DropdownMenuItemType.Divider\n    }, ...userOptions.filter(opt => opt.text.toLocaleLowerCase().indexOf(searchText.toLocaleLowerCase()) > -1)],\n    styles: dropdownStyles,\n    multiSelect: true,\n    onChange: onChangeDropDownOrOnIconClick,\n    selectedKeys: selectedValues,\n    calloutProps: {\n      directionalHintFixed: true\n    },\n    onRenderTitle: onRenderTitle,\n    //dropdownWidth=\"auto\"\n    id: \"MainDropDown\",\n    placeholder: \"Look for records\",\n    onRenderCaretDown: onRenderCaretDown,\n    onRenderOption: onRenderOption,\n    onDismiss: () => setSearchText(\"\"),\n    disabled: disabled\n  })));\n});\nLookupMultiSel.displayName = \"LookupMultiSel\";\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./LMS/LookupMultiSel.tsx?");

/***/ }),

/***/ "./LMS/WebApiOperations.ts":
/*!*********************************!*\
  !*** ./LMS/WebApiOperations.ts ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   Associate: () => (/* binding */ Associate),\n/* harmony export */   DisAssociate: () => (/* binding */ DisAssociate)\n/* harmony export */ });\n/*global Xrm */\n/*eslint no-undef: \"error\"*/\n//@ts-ignore\nvar url = Xrm.Utility.getGlobalContext().getClientUrl();\n/**\r\n * Associate selected record\r\n * @param selectedKey\r\n * @param primaryEntityType\r\n * @param relatedEntityType\r\n * @param relationshipName\r\n * @param primaryEntityId\r\n */\nvar Associate = (context, selectedKey, primaryEntityType, relatedEntityType, relationshipName, primaryEntityId) => {\n  var error = \"Issue while associating the record. Kindly check the configuration.\";\n  var association = {\n    \"@odata.id\": url + \"/api/data/v9.1/\".concat(relatedEntityType, \"s(\").concat(selectedKey, \")\")\n  };\n  var req = new XMLHttpRequest();\n  req.open(\"POST\", url + \"/api/data/v9.1/\".concat(primaryEntityType, \"s(\").concat(primaryEntityId, \")/\").concat(relationshipName, \"/$ref\"), true);\n  req.setRequestHeader(\"Accept\", \"application/json\");\n  req.setRequestHeader(\"Content-Type\", \"application/json; charset=utf-8\");\n  req.setRequestHeader(\"OData-MaxVersion\", \"4.0\");\n  req.setRequestHeader(\"OData-Version\", \"4.0\");\n  req.onreadystatechange = function () {\n    if (this.readyState === 4) {\n      req.onreadystatechange = null;\n      if (this.status === 204 || this.status === 1223) {\n        console.log(\"Associated\");\n      } else {\n        context.navigation.openAlertDialog(error);\n      }\n    }\n  };\n  req.send(JSON.stringify(association));\n};\n/**\r\n * Disassociate cancelled/unselected record\r\n * @param removedKey\r\n * @param primaryEntityType\r\n * @param relationshipName\r\n * @param primaryEntityId\r\n */\nvar DisAssociate = (context, removedKey, primaryEntityType, relationshipName, primaryEntityId) => {\n  var error = \"Issue while disassociating the record. Kindly check the configuration.\";\n  var req = new XMLHttpRequest();\n  req.open(\"DELETE\", url + \"/api/data/v9.1/\".concat(primaryEntityType, \"s(\").concat(primaryEntityId, \")/\").concat(relationshipName, \"(\").concat(removedKey, \")/$ref\"), true);\n  req.setRequestHeader(\"Accept\", \"application/json\");\n  req.setRequestHeader(\"Content-Type\", \"application/json; charset=utf-8\");\n  req.setRequestHeader(\"OData-MaxVersion\", \"4.0\");\n  req.setRequestHeader(\"OData-Version\", \"4.0\");\n  req.onreadystatechange = function () {\n    if (this.readyState === 4) {\n      req.onreadystatechange = null;\n      if (this.status === 204 || this.status === 1223) {\n        console.log(\"Disassociated\");\n      } else {\n        context.navigation.openAlertDialog(error);\n      }\n    }\n  };\n  req.send();\n};\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./LMS/WebApiOperations.ts?");

/***/ }),

/***/ "./LMS/index.ts":
/*!**********************!*\
  !*** ./LMS/index.ts ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   LMS: () => (/* binding */ LMS)\n/* harmony export */ });\n/* harmony import */ var _LookupMultiSel__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./LookupMultiSel */ \"./LMS/LookupMultiSel.tsx\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n\n\nclass LMS {\n  /**\r\n   * Empty constructor.\r\n   */\n  constructor() {\n    this.onChange = selectedValue => {\n      this.selectedOptions = selectedValue;\n      this.notifyOutputChanged();\n    };\n  }\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   */\n  init(context, notifyOutputChanged, state) {\n    this.notifyOutputChanged = notifyOutputChanged;\n    var initialSelectedValues = context.parameters.multiSelectedValues.raw;\n    this.initialValues = initialSelectedValues == null ? [] : initialSelectedValues.split(\",\");\n  }\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   * @returns ReactElement root react element for the control\r\n   */\n  updateView(context) {\n    var props = {\n      onChange: this.onChange,\n      initialValues: this.initialValues,\n      context: context,\n      relatedEntityType: context.parameters.relatedEntityType.raw,\n      relatedPrimaryColumns: context.parameters.relatedPrimaryColumns.raw.split(\",\").map(value => value.trim()),\n      primaryEntityType: context.parameters.primaryEntityType.raw,\n      relationshipName: context.parameters.relationshipName.raw,\n      primaryEntityId: context.parameters.primaryEntityId.raw,\n      disabled: context.parameters.primaryEntityId.raw == null ? true : context.mode.isControlDisabled\n    };\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1__.createElement(_LookupMultiSel__WEBPACK_IMPORTED_MODULE_0__.LookupMultiSel, props);\n  }\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n  getOutputs() {\n    return {\n      multiSelectedValues: this.selectedOptions.toString()\n    };\n  }\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n  destroy() {\n    // Add code to cleanup control if necessary\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./LMS/index.ts?");

/***/ }),

/***/ "@fluentui/react/lib/Dropdown":
/*!*************************************!*\
  !*** external "FluentUIReactv8290" ***!
  \*************************************/
/***/ ((module) => {

module.exports = FluentUIReactv8290;

/***/ }),

/***/ "react":
/*!***************************!*\
  !*** external "Reactv16" ***!
  \***************************/
/***/ ((module) => {

module.exports = Reactv16;

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./LMS/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('LookUpMulSel.LMS', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.LMS);
} else {
	var LookUpMulSel = LookUpMulSel || {};
	LookUpMulSel.LMS = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.LMS;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}